from .vreport import GenerateVolitalityReport
